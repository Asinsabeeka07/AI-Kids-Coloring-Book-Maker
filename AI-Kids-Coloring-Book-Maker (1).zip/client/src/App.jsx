import React, { useMemo, useRef, useState } from "react";

const MAX_FILE_MB = 20;
const ACCEPTED = ["image/jpeg", "image/png", "image/webp"];

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function App() {
  const inputRef = useRef(null);
  const [pages, setPages] = useState([]);
  const [original, setOriginal] = useState(null);
  const [selectedFile, setSelectedFile] = useState(null);
  const [generated, setGenerated] = useState(null);
  const [busy, setBusy] = useState(false);
  const [pdfBusy, setPdfBusy] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [dragIndex, setDragIndex] = useState(null);
  const [settings, setSettings] = useState({
    size: "A4",
    orientation: "portrait",
    margin: "medium",
    title: "My Kids Coloring Book",
    cover: false
  });
  const [pdfUrl, setPdfUrl] = useState("");

  const hasPendingImage = Boolean(selectedFile && original && !generated);

  const pageCountLabel = useMemo(
    () => `${pages.length} ${pages.length === 1 ? "page" : "pages"}`,
    [pages.length]
  );

  function clearMessages() {
    setError("");
    setSuccess("");
  }

  async function handleFile(file) {
    clearMessages();
    setGenerated(null);
    setSelectedFile(null);

    if (!file) return;
    if (!ACCEPTED.includes(file.type)) {
      setError("Please upload a JPG, JPEG, PNG, or WEBP image.");
      return;
    }
    if (file.size > MAX_FILE_MB * 1024 * 1024) {
      setError(`That image is too large. Please keep it under ${MAX_FILE_MB} MB.`);
      return;
    }

    try {
      const dataUrl = await fileToDataUrl(file);
      setOriginal(dataUrl);
      setSelectedFile(file);
    } catch {
      setError("We couldn't read that image. Please try again.");
    }
  }

  function onInputChange(e) {
    handleFile(e.target.files?.[0]);
    e.target.value = "";
  }

  async function convertImage() {
    if (!selectedFile) return;
    clearMessages();
    setBusy(true);

    try {
      const form = new FormData();
      form.append("image", selectedFile);

      const response = await fetch("/api/convert", {
        method: "POST",
        body: form
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Conversion failed.");

      setGenerated(data.image);
      setPages((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          original: original,
          image: data.image
        }
      ]);
      setSuccess("✓ Coloring page created and added to your book.");
    } catch (err) {
      setError(err.message || "We couldn't create this coloring page.");
    } finally {
      setBusy(false);
    }
  }

  function addAnother() {
    clearMessages();
    setOriginal(null);
    setSelectedFile(null);
    setGenerated(null);
    inputRef.current?.click();
  }

  function deletePage(id) {
    setPages((current) => current.filter((p) => p.id !== id));
    setSuccess("Page removed.");
  }

  function onDragStart(index) {
    setDragIndex(index);
  }

  function onDrop(index) {
    if (dragIndex === null || dragIndex === index) return;
    setPages((current) => {
      const copy = [...current];
      const [moved] = copy.splice(dragIndex, 1);
      copy.splice(index, 0, moved);
      return copy;
    });
    setDragIndex(null);
  }

  async function createPdf() {
    if (!pages.length) {
      setError("Add at least one coloring page before creating a PDF.");
      return;
    }

    clearMessages();
    setPdfBusy(true);
    setPdfUrl("");

    try {
      const response = await fetch("/api/create-pdf", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          pages: pages.map((p) => p.image),
          settings
        })
      });

      if (!response.ok) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || "PDF generation failed.");
      }

      const blob = await response.blob();
      const url = URL.createObjectURL(blob);
      setPdfUrl(url);
      setSuccess("✓ Your printable coloring book is ready.");
    } catch (err) {
      setError(err.message || "We couldn't create the PDF.");
    } finally {
      setPdfBusy(false);
    }
  }

  function downloadPdf() {
    if (!pdfUrl) return;
    const a = document.createElement("a");
    a.href = pdfUrl;
    a.download = `${(settings.title || "coloring-book").replace(/[^\w\-]+/g, "-")}.pdf`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">🎨</div>
          <div>
            <h1>My Kids Coloring Book</h1>
            <p>Upload images and turn them into printable coloring pages.</p>
          </div>
        </div>
        <div className="page-count">{pageCountLabel}</div>
      </header>

      <main className="container">
        <section className="hero-card">
          <div className="hero-copy">
            <span className="eyebrow">AI COLORING PAGE MAKER</span>
            <h2>Turn your own pictures into a coloring book ✨</h2>
            <p>
              Upload one image at a time. The AI converts it into clean,
              child-friendly black-and-white line art and adds it to your book.
            </p>
          </div>

          <div
            className="upload-zone"
            onDragOver={(e) => e.preventDefault()}
            onDrop={(e) => {
              e.preventDefault();
              handleFile(e.dataTransfer.files?.[0]);
            }}
          >
            <div className="upload-icon">↑</div>
            <h3>Drop one image here</h3>
            <p>JPG, PNG, WEBP · up to {MAX_FILE_MB} MB</p>
            <button className="primary-btn" onClick={() => inputRef.current?.click()}>
              + Upload Image
            </button>
            <input
              ref={inputRef}
              type="file"
              hidden
              accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp"
              onChange={onInputChange}
            />
          </div>
        </section>

        {error && <div className="alert error">⚠️ {error}</div>}
        {success && <div className="alert success">{success}</div>}

        {original && (
          <section className="workspace-card">
            <div className="section-heading">
              <div>
                <span className="eyebrow">CURRENT IMAGE</span>
                <h2>Preview & convert</h2>
              </div>
              {generated && <span className="created-badge">✓ Created</span>}
            </div>

            <div className="comparison">
              <div className="image-panel">
                <div className="panel-label">Original image</div>
                <div className="image-frame">
                  <img src={original} alt="Uploaded original" />
                </div>
              </div>

              <div className="arrow-divider">→</div>

              <div className="image-panel">
                <div className="panel-label">Coloring page</div>
                <div className="image-frame generated-frame">
                  {generated ? (
                    <img src={generated} alt="Generated coloring page" />
                  ) : (
                    <div className="empty-preview">
                      <span>✦</span>
                      <p>Your clean line-art page will appear here.</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="action-row">
              {!generated ? (
                <button className="primary-btn large" disabled={busy} onClick={convertImage}>
                  {busy ? (
                    <>
                      <span className="spinner" /> Creating your coloring page...
                    </>
                  ) : (
                    "✨ Convert to Coloring Page"
                  )}
                </button>
              ) : (
                <button className="secondary-btn large" onClick={addAnother}>
                  + Add Another Page
                </button>
              )}
            </div>
          </section>
        )}

        <section className="book-layout">
          <div className="book-card">
            <div className="section-heading">
              <div>
                <span className="eyebrow">YOUR BOOK</span>
                <h2>Page Preview</h2>
              </div>
              {pages.length > 0 && (
                <button className="text-btn" onClick={addAnother}>+ Add page</button>
              )}
            </div>

            {pages.length === 0 ? (
              <div className="empty-book">
                <div className="empty-book-icon">📖</div>
                <h3>Your coloring book is empty</h3>
                <p>Upload your first image and turn it into a coloring page.</p>
                <button className="primary-btn" onClick={() => inputRef.current?.click()}>
                  + Upload First Image
                </button>
              </div>
            ) : (
              <div className="page-grid">
                {pages.map((page, index) => (
                  <article
                    className="page-card"
                    key={page.id}
                    draggable
                    onDragStart={() => onDragStart(index)}
                    onDragOver={(e) => e.preventDefault()}
                    onDrop={() => onDrop(index)}
                  >
                    <div className="page-card-top">
                      <span>Page {index + 1}</span>
                      <button
                        className="icon-btn danger"
                        title="Delete page"
                        onClick={() => deletePage(page.id)}
                      >
                        ×
                      </button>
                    </div>
                    <div className="page-thumb">
                      <img src={page.image} alt={`Coloring page ${index + 1}`} />
                    </div>
                    <div className="drag-hint">☰ Drag to reorder</div>
                  </article>
                ))}
              </div>
            )}
          </div>

          <aside className="settings-card">
            <div className="section-heading compact">
              <div>
                <span className="eyebrow">BOOK SETTINGS</span>
                <h2>Print options</h2>
              </div>
            </div>

            <label>
              <span>Book title</span>
              <input
                value={settings.title}
                onChange={(e) => setSettings({ ...settings, title: e.target.value })}
                placeholder="My Kids Coloring Book"
              />
            </label>

            <fieldset>
              <legend>Page size</legend>
              <div className="choice-row">
                {["A4", "US Letter"].map((value) => (
                  <button
                    key={value}
                    className={settings.size === value ? "choice active" : "choice"}
                    onClick={() => setSettings({ ...settings, size: value })}
                  >
                    {value}
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend>Orientation</legend>
              <div className="choice-row">
                {["portrait", "landscape"].map((value) => (
                  <button
                    key={value}
                    className={settings.orientation === value ? "choice active" : "choice"}
                    onClick={() => setSettings({ ...settings, orientation: value })}
                  >
                    {value[0].toUpperCase() + value.slice(1)}
                  </button>
                ))}
              </div>
            </fieldset>

            <fieldset>
              <legend>Margins</legend>
              <div className="choice-row three">
                {["small", "medium", "large"].map((value) => (
                  <button
                    key={value}
                    className={settings.margin === value ? "choice active" : "choice"}
                    onClick={() => setSettings({ ...settings, margin: value })}
                  >
                    {value[0].toUpperCase() + value.slice(1)}
                  </button>
                ))}
              </div>
            </fieldset>

            <label className="checkbox-row">
              <input
                type="checkbox"
                checked={settings.cover}
                onChange={(e) => setSettings({ ...settings, cover: e.target.checked })}
              />
              <span>
                <strong>Include cover page</strong>
                <small>Add a simple printable title cover.</small>
              </span>
            </label>

            <button
              className="primary-btn full"
              disabled={!pages.length || pdfBusy}
              onClick={createPdf}
            >
              {pdfBusy ? (
                <>
                  <span className="spinner" /> Creating PDF...
                </>
              ) : (
                "📄 Create PDF"
              )}
            </button>

            {pdfUrl && (
              <button className="secondary-btn full" onClick={downloadPdf}>
                ⬇ Download PDF
              </button>
            )}
          </aside>
        </section>

        {pdfUrl && (
          <section className="pdf-card">
            <div className="section-heading">
              <div>
                <span className="eyebrow">FINAL PREVIEW</span>
                <h2>Complete coloring book</h2>
              </div>
              <button className="secondary-btn" onClick={downloadPdf}>Download PDF</button>
            </div>
            <iframe title="PDF preview" src={pdfUrl} />
          </section>
        )}

        <footer>
          <span>Made for printable kids coloring books</span>
          <span>•</span>
          <span>Upload your own images · Build · Print</span>
        </footer>
      </main>
    </div>
  );
}

export default App;
