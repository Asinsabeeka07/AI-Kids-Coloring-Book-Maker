# AI Kids Coloring Book Maker

This is a React/Vite frontend with an Express backend.

Run:
- `npm run dev` for frontend development
- `npm run server` for the backend
- `npm run build && npm start` for the production-style Replit workflow

Required secret:
- `OPENAI_API_KEY`

AI conversion is performed server-side through the OpenAI image-editing API. PDF creation is local/server-side with pdf-lib.
