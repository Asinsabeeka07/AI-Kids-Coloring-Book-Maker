# 🎨 AI Kids Coloring Book Maker

A React + Express app that lets a user upload images one at a time, transform each image into clean black-and-white children's coloring-page line art with an AI image-editing model, arrange the pages, and export the whole book as a printable PDF.

## Features

- One-image-at-a-time upload
- JPG / JPEG / PNG / WEBP support
- Real AI image-to-line-art conversion
- Original vs generated preview
- Automatic page creation
- Drag-and-drop page reordering
- Delete pages
- A4 / US Letter
- Portrait / Landscape
- Small / Medium / Large margins
- Optional printable title cover
- High-quality PDF generation
- Browser PDF preview
- Downloadable PDF
- API keys kept on the backend

## AI setup

This project uses the OpenAI image-editing API from the backend. The current OpenAI Node SDK exposes `client.images.edit()` for GPT Image models. Keep the key server-side.

In Replit, open **Secrets / Environment Variables** and add:

```text
OPENAI_API_KEY=your_key_here
```

Optional:

```text
IMAGE_MODEL=gpt-image-2
```

If the key is missing, the app will show a clear configuration message instead of pretending that conversion worked.

## Run locally

```bash
npm install
npm run dev
```

For the AI/PDF backend in a separate terminal:

```bash
npm run server
```

The Vite development server proxies `/api` requests to the backend on port 3001.

For a production-style build:

```bash
npm run build
npm start
```

## Replit

1. Import this project.
2. Run `npm install`.
3. Add `OPENAI_API_KEY` to Replit Secrets.
4. Run `npm run build`.
5. Run `npm start`.

The Express server serves the compiled React app from `dist`.

## Important

The application does not contain a predefined coloring-book catalog. Every coloring page comes from an image uploaded by the user.

The AI prompt is designed to preserve the uploaded subject while simplifying it into child-friendly line art:
- black outlines
- white background
- no gray shading
- no colors
- large coloring areas
- simplified details

PDF generation is independent from AI conversion: once pages have been generated, the PDF endpoint only combines those generated images.

## Selling printables

Before selling a finished book, make sure you have the rights to use every source image and that the AI provider's current terms allow your intended commercial use. Also review the generated pages yourself for quality and accidental artifacts.
