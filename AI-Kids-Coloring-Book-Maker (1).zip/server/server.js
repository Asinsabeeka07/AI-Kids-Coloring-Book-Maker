import "dotenv/config";
import express from "express";
import multer from "multer";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { convertToColoringPage } from "./services/imageConverter.js";
import { createColoringBookPdf } from "./services/pdfGenerator.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3001);

const uploadDir = path.join(__dirname, "tmp");
fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ["image/jpeg", "image/png", "image/webp"];
    cb(null, allowed.includes(file.mimetype));
  }
});

app.use(express.json({ limit: "60mb" }));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    aiConfigured: Boolean(process.env.OPENAI_API_KEY)
  });
});

app.post("/api/convert", upload.single("image"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "Please upload a JPG, PNG, or WEBP image." });
  }

  try {
    const image = await convertToColoringPage(req.file.path);
    res.json({ image });
  } catch (error) {
    console.error("Conversion error:", error);
    const status = error.code === "MISSING_AI_KEY" ? 503 : 500;
    res.status(status).json({
      error:
        error.code === "MISSING_AI_KEY"
          ? "AI conversion is not configured. Add OPENAI_API_KEY in your Replit Secrets."
          : "We couldn't create this coloring page. Please try another image."
    });
  } finally {
    fs.promises.unlink(req.file.path).catch(() => {});
  }
});

app.post("/api/create-pdf", async (req, res) => {
  try {
    const { pages, settings } = req.body || {};
    const pdf = await createColoringBookPdf({ pages, settings });

    const safeTitle = String(settings?.title || "coloring-book")
      .replace(/[^\w\-]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "coloring-book";

    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${safeTitle}.pdf"`);
    res.send(pdf);
  } catch (error) {
    console.error("PDF error:", error);
    res.status(500).json({ error: "We couldn't create the PDF. Please try again." });
  }
});

const clientDist = path.join(__dirname, "..", "dist");
if (fs.existsSync(clientDist)) {
  app.use(express.static(clientDist));
  app.get("*splat", (_req, res) => {
    res.sendFile(path.join(clientDist, "index.html"));
  });
}

app.listen(PORT, "0.0.0.0", () => {
  console.log(`AI Kids Coloring Book Maker running on port ${PORT}`);
});
