import OpenAI, { toFile } from "openai";
import fs from "node:fs";

const STYLE_PROMPT = `
Transform the supplied image into a printable children's coloring-book page.

Preserve the main subject and its recognizable identity, pose, silhouette, and important features.
Do not invent a different subject.

OUTPUT STYLE:
- pure white background
- clean black line art only
- smooth, confident, moderately thick outlines
- no color
- no gray
- no gradients
- no shadows
- no photographic texture
- simplify tiny details
- remove distracting background details
- keep large open areas for coloring
- suitable for children ages 4 to 8
- friendly professional coloring-book illustration
- clean closed contours wherever practical
- centered composition
- preserve the subject's important details
- do not add captions, labels, borders, or decorative text

The final result must look like a real printable coloring page, not a grayscale photo.
`;

export async function convertToColoringPage(filePath) {
  if (!process.env.OPENAI_API_KEY) {
    const error = new Error(
      "AI conversion is not configured. Add OPENAI_API_KEY to your Replit Secrets/environment variables."
    );
    error.code = "MISSING_AI_KEY";
    throw error;
  }

  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const image = await toFile(fs.createReadStream(filePath));

  const result = await client.images.edit({
    model: process.env.IMAGE_MODEL || "gpt-image-2",
    image,
    prompt: STYLE_PROMPT,
    quality: "medium",
    output_format: "png",
    background: "opaque"
  });

  const base64 = result.data?.[0]?.b64_json;
  if (!base64) throw new Error("The AI service did not return an image.");

  return `data:image/png;base64,${base64}`;
}
