import { PDFDocument, rgb, StandardFonts } from "pdf-lib";

const PAGE_SIZES = {
  A4: { width: 595.28, height: 841.89 },
  "US Letter": { width: 612, height: 792 }
};

const MARGINS = {
  small: 28,
  medium: 45,
  large: 65
};

function parseDataUrl(dataUrl) {
  const match = /^data:image\/(png|jpeg|jpg|webp);base64,(.+)$/i.exec(dataUrl || "");
  if (!match) throw new Error("Invalid generated image format.");
  return Buffer.from(match[2], "base64");
}

async function embedImage(pdf, dataUrl) {
  const bytes = parseDataUrl(dataUrl);
  const lower = dataUrl.slice(0, 40).toLowerCase();

  if (lower.includes("image/png")) return pdf.embedPng(bytes);

  // Generated pages from the AI service are PNG. JPEG support is kept for robustness.
  if (lower.includes("image/jpeg") || lower.includes("image/jpg")) {
    return pdf.embedJpg(bytes);
  }

  throw new Error("Unsupported PDF image format.");
}

export async function createColoringBookPdf({ pages, settings }) {
  if (!Array.isArray(pages) || pages.length === 0) {
    throw new Error("At least one coloring page is required.");
  }

  const pdf = await PDFDocument.create();
  const base = PAGE_SIZES[settings?.size] || PAGE_SIZES.A4;
  const landscape = settings?.orientation === "landscape";
  const width = landscape ? base.height : base.width;
  const height = landscape ? base.width : base.height;
  const margin = MARGINS[settings?.margin] || MARGINS.medium;

  if (settings?.cover) {
    const cover = pdf.addPage([width, height]);
    const font = await pdf.embedFont(StandardFonts.HelveticaBold);
    const title = String(settings?.title || "My Kids Coloring Book").slice(0, 100);
    const fontSize = Math.min(34, Math.max(20, 420 / Math.max(title.length, 12)));
    const titleWidth = font.widthOfTextAtSize(title, fontSize);

    cover.drawText(title, {
      x: (width - titleWidth) / 2,
      y: height / 2 + 20,
      size: fontSize,
      font,
      color: rgb(0, 0, 0)
    });

    const regular = await pdf.embedFont(StandardFonts.Helvetica);
    const subtitle = "Printable Coloring Pages";
    const subtitleWidth = regular.widthOfTextAtSize(subtitle, 14);

    cover.drawText(subtitle, {
      x: (width - subtitleWidth) / 2,
      y: height / 2 - 10,
      size: 14,
      font: regular,
      color: rgb(0, 0, 0)
    });
  }

  for (const pageData of pages) {
    const page = pdf.addPage([width, height]);
    const image = await embedImage(pdf, pageData);
    const dims = image.scale(1);

    const availableW = width - margin * 2;
    const availableH = height - margin * 2;
    const scale = Math.min(availableW / dims.width, availableH / dims.height);

    const drawW = dims.width * scale;
    const drawH = dims.height * scale;

    page.drawImage(image, {
      x: (width - drawW) / 2,
      y: (height - drawH) / 2,
      width: drawW,
      height: drawH
    });
  }

  return Buffer.from(await pdf.save({ useObjectStreams: false }));
}
